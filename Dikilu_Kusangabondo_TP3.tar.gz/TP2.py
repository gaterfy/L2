#Question 10

def deux_puissance(n):
    """
    """
    assert n >= 0, "n doit être superieur à 0"
    b = 1
    for x in range(n):
        b = b << 1
    return b

def pair(n):
    """
    """
    if n&1 == 0:
        return True
    else:
        return False

def integer_to_binary_str(n):
    """
    """
    nb_bin = ""
    while n > 0:
        if pair(n):
            nb_bin = "0" + nb_bin
            n = n >> 1
        else:
            nb_bin = "1" + nb_bin
            n = n >> 1
    return nb_bin

def binary_str_to_integer(n):
    """
    """
    nb_dec = 0
    for i in range(len(n)):
        if n[i] == "1":
            nb_dec =  (nb_dec << 1) | 1
        else:
            nb_dec = nb_dec << 1
    return nb_dec
