# Dikilu Florian et Kunsangabondo Berfy


# Question 2:

# Question 3:
# Le fichier coder prend plus de place que le fichier .txt

BASE64_SYMBOLS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
                  'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
                  'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
                  'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
                  'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
                  'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
                  'w', 'x', 'y', 'z', '0', '1', '2', '3',
                  '4', '5', '6', '7', '8', '9', '+', '/']

#   >>> BASE64_SYMBOLS[14]
#   'O'
#   >>> BASE64_SYMBOLS[1]
#   'B'
#   >>> BASE64_SYMBOLS[59]
#   '7'
#   >>> BASE64_SYMBOLS[35]
#   'j'

import sys
import TP2 as tp2

def binary_str8(n):
    """
    Return str of len(n) = 8

    :param n: n - binary string
    :type n: str
    :return: binary string of bites
    :return type: str
    :CU: len(n) <= 8
    :examples:
    >>> binary_str('0110')
    '00000110'
    >>> binary_str('1')
    '00000001'
    """
    while len(n) < 8:
        n = '0' + n
    return n

def bytes_to_symbols(data):
    """
    Takes (at most) three bytes of data in input and returns the corresponding bas64 symbols.

    :Param data:	data – A list of at most three bytes
    :Return:	Four base64 symbols corresponding to the data given in input
    :Return type: str
    :CU:	len(data) <= 3
    Examples:
    >>> bytes_to_symbols([5])
    'BQ=='
    >>> bytes_to_symbols([4, 163])
    'BKM='
    >>> bytes_to_symbols([28, 89, 101])
    'HFll'
    >>> bytes_to_symbols([])
    ''
    """
    assert len(data) <= 3
    aux = ''
    aux2 = ''
    aux3 = ''
    aux4 = ''
    if len(data) == 1:   
        bin_str = binary_str8(tp2.integer_to_binary_str(data[0]))
        for i in range(len(bin_str)-2):
            aux = aux + bin_str[i]
        aux2 = bin_str[-2] + bin_str[-1] + '0000'
        return BASE64_SYMBOLS[tp2.binary_str_to_integer(aux)] + BASE64_SYMBOLS[tp2.binary_str_to_integer(aux2)] + '=='
    elif len(data) == 2:
        bin_str1 = binary_str8(tp2.integer_to_binary_str(data[0]))
        for i in range(len(bin_str1)-2):
            aux = aux + bin_str1[i]
        aux2 = bin_str1[-2] + bin_str1[-1]
        bin_str2 = binary_str8(tp2.integer_to_binary_str(data[1]))
        for j in range(len(bin_str2)-4):
            aux2 = aux2 + bin_str2[j]
        aux3 = bin_str2[-4] + bin_str2[-3] + bin_str2[-2] + bin_str2[-1] + '00'
        return BASE64_SYMBOLS[tp2.binary_str_to_integer(aux)] + BASE64_SYMBOLS[tp2.binary_str_to_integer(aux2)] + BASE64_SYMBOLS[tp2.binary_str_to_integer(aux3)] + '='
    elif len(data) == 3:
        bin_str1 = binary_str8(tp2.integer_to_binary_str(data[0]))
        for i in range(len(bin_str1)-2):
            aux = aux + bin_str1[i]
        aux2 = bin_str1[-2] + bin_str1[-1]
        bin_str2 = binary_str8(tp2.integer_to_binary_str(data[1]))
        for j in range(len(bin_str2)-4):
            aux2 = aux2 + bin_str2[j]
        aux3 = bin_str2[-4] + bin_str2[-3] + bin_str2[-2] + bin_str2[-1]
        bin_str3 = binary_str8(tp2.integer_to_binary_str(data[2]))
        aux3 = aux3 + bin_str3[0] + bin_str3[1]
        for k in range(len(bin_str3)-2):
            aux4 = aux4 + bin_str3[k+2]
        return BASE64_SYMBOLS[tp2.binary_str_to_integer(aux)] + BASE64_SYMBOLS[tp2.binary_str_to_integer(aux2)] + BASE64_SYMBOLS[tp2.binary_str_to_integer(aux3)] + BASE64_SYMBOLS[tp2.binary_str_to_integer(aux4)]
    else:
        return ''

def  base64_encode(source):
    '''
    Encode a file in base64 and outputs the result on standard output.

    :param source: the source filename
    :type source: str
    :example:
    >>> base64_encode("deuxEgale.txt")
    SmUgZmFpcyB1bmUgcGhyYXNlIGRlIG1hbmnDqHJlIMOgIGNlIHF1J2lsIHkgYWl0IGRldXggw6lnYWxlCg==
    '''
    input = open(source, 'rb')
    data = input.read(3)
    nb = 0
    while len(data) > 0:
        nb = nb + 1
        if (nb%19)==0:
            print (bytes_to_symbols(data), end='\n')
            data = input.read(3)
        else:
            print (bytes_to_symbols(data), end='')
            data = input.read(3)
    print()
    input.close();

def decode_base64_symbol(symbol):
    """
    decode a symbol in base 64

    :param symbol: symbol of base 64
    :type symbol: str
    :return: decode symbol
    :return type: int
    :CU: the symbol is part of the base64 symbols
    :example:
    >>> decode_base64_symbol('Z')
    25
    >>> decode_base64_symbol('+')
    62
    """
    return BASE64_SYMBOLS.index(symbol)

def binary_str6(n):
    """
    Return str of len(n) = 6

    :param n: n - binary string
    :type n: str
    :return: binary string of bites
    :return type: str
    :CU: len(n) <= 6
    :examples:
    >>> binary_str('0110')
    '000110'
    >>> binary_str('1')
    '000001'
    """
    while len(n) < 6:
        n = '0' + n
    return n

def symbols_to_bytes(symbols):
    """
    Convert base64 symbols to bytes
    :param symbols: a string of four base64 symbols
    :type symbols: str
    :return: a list of one to 3 bytes whose values correspond to the base64 symbols
    :return type: list
    :CU: len(symbols) == 4
    :examples:
    >>> symbols_to_bytes('BQ==')
    [5]
    >>> symbols_to_bytes('BKM=')
    [4, 163]
    >>> symbols_to_bytes('HFll')
    [28, 89, 101]
    """
    assert len(symbols) == 4, "La longueur du paramètre doit etre de 4"
    aux1 = ''
    aux2 = ''
    aux3 = ''
    if symbols[-1] == '=' and symbols[-2] == '=':
        bin_sym1 = binary_str6(tp2.integer_to_binary_str(decode_base64_symbol(symbols[0])))
        bin_sym2 = binary_str6(tp2.integer_to_binary_str(decode_base64_symbol(symbols[1])))
        for i in range(len(bin_sym1)):
            aux1 = aux1 + bin_sym1[i]
        aux1 = aux1 + bin_sym2[0] + bin_sym2[1]
        return [tp2.binary_str_to_integer(aux1)]
    elif symbols[-1] == '=' and not(symbols[-2]  == '='):
        bin_sym1 = binary_str6(tp2.integer_to_binary_str(decode_base64_symbol(symbols[0])))
        bin_sym2 = binary_str6(tp2.integer_to_binary_str(decode_base64_symbol(symbols[1])))
        bin_sym3 = binary_str6(tp2.integer_to_binary_str(decode_base64_symbol(symbols[2])))
        for i in range(len(bin_sym1)):
            aux1 = aux1 + bin_sym1[i]
        aux1 = aux1 + bin_sym2[0] + bin_sym2[1]
        for j in range(len(bin_sym2)-2):
            aux2 = aux2 + bin_sym2[j+2]
        aux2 = aux2 + bin_sym3[0] + bin_sym3[1] + bin_sym3[2] + bin_sym3[3]
        return [tp2.binary_str_to_integer(aux1),tp2.binary_str_to_integer(aux2)]
    else:
        bin_sym1 = binary_str6(tp2.integer_to_binary_str(decode_base64_symbol(symbols[0])))
        bin_sym2 = binary_str6(tp2.integer_to_binary_str(decode_base64_symbol(symbols[1])))
        bin_sym3 = binary_str6(tp2.integer_to_binary_str(decode_base64_symbol(symbols[2])))
        bin_sym4 = binary_str6(tp2.integer_to_binary_str(decode_base64_symbol(symbols[3])))
        for i in range(len(bin_sym1)):
            aux1 = aux1 + bin_sym1[i]
        aux1 = aux1 + bin_sym2[0] + bin_sym2[1]
        for j in range(len(bin_sym2)-2):
            aux2 = aux2 + bin_sym2[j+2]
        aux2 = aux2 + bin_sym3[0] + bin_sym3[1] + bin_sym3[2] + bin_sym3[3]
        aux3 = bin_sym3[4] + bin_sym3[5]
        for k in range(len(bin_sym4)):
            aux3 = aux3 + bin_sym4[k]
        return [tp2.binary_str_to_integer(aux1),tp2.binary_str_to_integer(aux2),tp2.binary_str_to_integer(aux3)]

def process_base64_line(line):
    """
    Create file with decode line
    :param line: line of file
    :type line: str
    :CU: len(line)%4 == 0
    """
    source = open("line.txt","ab")
    for i in range(0,len(line),4):
        source.write(bytes(symbols_to_bytes(line[i:i+4])))
    source.close()

def base64_decode(source):
    """
    Create file with decode source
    :param source: file to decode
    :type source: file
    """
    fichier = open(source,"r")
    liste = fichier.readlines()
    liste_aux= []
    for i in liste:
        liste_aux = liste_aux + [i.strip()]
    for j in liste_aux:
        process_base64_line(j)
    fichier.close()
    
    
